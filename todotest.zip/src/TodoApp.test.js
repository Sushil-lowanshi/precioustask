// // import React from 'react';
// // import { render, fireEvent, screen } from '@testing-library/react';
// // import '@testing-library/jest-dom';
// // import TodoApp from './components/TodoApp.jsx';

// //   test('renders correctly and shows list', () => {
// //     render(<TodoApp />);
// //     expect(screen.getByText('Add Your List Here ✌')).toBeInTheDocument();
// //   });


// // // describe('TodoApp Component', () => {
// // //   test('renders correctly and shows list', () => {
// // //     render(<TodoApp />);
// // //     expect(screen.getByText('Add Your List Here ✌')).toBeInTheDocument();
// // //   });

// //   // test('adds a new item in the list', () => {
// //   //   render(<TodoApp />);
// //   //   fireEvent.change(input, { target: { value: 'orange' } });

// //   //   const addButton = screen.getByRole('button', { name: /add/i });
// //   //   fireEvent.click(addButton);

// //   //   expect(screen.getByText('orange')).toBeInTheDocument();
// //   // });

// //   // test('edits an item in the list', () => {
// //   //   render(<TodoApp />);
// //   //   const editButton = screen.getAllByLabelText('edit')[0];
// //   //   fireEvent.click(editButton);

// //   //   fireEvent.change(input, { target: { value: 'apple updated' } });

// //   //   const saveButton = screen.getByRole('button', { name: /edit/i });
// //   //   fireEvent.click(saveButton);

// //   //   expect(screen.getByText('apple updated')).toBeInTheDocument();
// //   //   expect(screen.queryByText('apple')).not.toBeInTheDocument();
// //   // });

// //   // test('deletes item in the list', () => {
// //   //   render(<TodoApp />);
// //   //   const deleteButton = screen.getAllByLabelText('delete')[0]; 
// //   //   fireEvent.click(deleteButton);

// //   //   expect(screen.queryByText('apple')).not.toBeInTheDocument();
// //   // });

// //   // test('clears all items', () => {
// //   //   render(<TodoApp />);
// //   //   const deleteAllButton = screen.getByRole('button', { name: /delete all/i });
// //   //   fireEvent.click(deleteAllButton);
// //   // });
// // // });



// import React from 'react';
// import { render, fireEvent, screen } from '@testing-library/react';
// import '@testing-library/jest-dom';
// import TodoApp from './components/TodoApp';

// describe('TodoApp Component', () => {
//   test('renders correctly and shows initial list', () => {
//     render(<TodoApp />);
//     expect(screen.getByText('Add Your List Here ✌')).toBeInTheDocument();
//     expect(screen.getByText('apple')).toBeInTheDocument();
//     expect(screen.getByText('banana')).toBeInTheDocument();
//     expect(screen.getByText('mangos')).toBeInTheDocument();
//   });

//   test('adds a new item to the list', () => {
//     render(<TodoApp />);
//     const input = screen.getByPlaceholderText('✍️ Add or Edit Items...');
//     fireEvent.change(input, { target: { value: 'orange' } });

//     const addButton = screen.getByRole('button', { name: /add/i });
//     fireEvent.click(addButton);

//     expect(screen.getByText('orange')).toBeInTheDocument();
//   });

//   test('edits an item in the list', () => {
//     render(<TodoApp />);
//     const editButton = screen.getAllByLabelText('edit')[0]; // Select the first edit button (for 'apple')
//     fireEvent.click(editButton);

//     const input = screen.getByPlaceholderText('✍️ Add or Edit Items...');
//     fireEvent.change(input, { target: { value: 'apple updated' } });

//     const saveButton = screen.getByRole('button', { name: /edit/i });
//     fireEvent.click(saveButton);

//     expect(screen.getByText('apple updated')).toBeInTheDocument();
//     expect(screen.queryByText('apple')).not.toBeInTheDocument();
//   });

//   test('deletes an item from the list', () => {
//     render(<TodoApp />);
//     const deleteButton = screen.getAllByLabelText('delete')[0]; // Select the first delete button (for 'apple')
//     fireEvent.click(deleteButton);

//     expect(screen.queryByText('apple')).not.toBeInTheDocument();
//   });

//   test('clears all items from the list', () => {
//     // render(<TodoApp />);
//     const deleteAllButton = screen.getByRole('button', { name: /delete all/i });
//     fireEvent.click(deleteAllButton);

//     expect(screen.queryByText('apple')).not.toBeInTheDocument();
//     expect(screen.queryByText('banana')).not.toBeInTheDocument();
//     expect(screen.queryByText('mangos')).not.toBeInTheDocument();
//   });
// });
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import TodoApp from './TodoApp'; // Assuming TodoApp is in the same directory
import '@testing-library/jest-dom';

describe('TodoApp Component', () => {
  beforeEach(() => {
    render(<TodoApp />);
  });

  test('when input is changed, then it updates the state', () => {
    const input = screen.getByPlaceholderText('✍️ Add or Edit Items...');
    fireEvent.change(input, { target: { value: 'New Item' } });
    expect(input.value).toBe('New Item');
  });

  test('when Add button is clicked with valid input, then the item is added to the list', () => {
    const input = screen.getByPlaceholderText('✍️ Add or Edit Items...');
    const addButton = screen.getByRole('button', { name: /add/i });

    fireEvent.change(input, { target: { value: 'Pineapple' } });
    fireEvent.click(addButton);

    const newItem = screen.getByText('Pineapple');
    expect(newItem).toBeInTheDocument();
  });

  test('when Add button is clicked with empty input, then the item is not added to the list', () => {
    const addButton = screen.getByRole('button', { name: /add/i });
    fireEvent.click(addButton);

    const listItems = screen.getAllByRole('listitem');
    expect(listItems).toHaveLength(3); // Initially, there are 3 items (apple, banana, mangos)
  });

  test('when Delete button is clicked, then the item is removed from the list', () => {
    const deleteButton = screen.getAllByLabelText('delete')[0]; // Get the delete button of the first item
    fireEvent.click(deleteButton);

    const removedItem = screen.queryByText('apple'); // apple should be removed
    expect(removedItem).not.toBeInTheDocument();
  });

  test('when Delete All button is clicked, then all items are removed from the list', () => {
    const deleteAllButton = screen.getByText(/delete all/i);
    fireEvent.click(deleteAllButton);

    const noItemsMessage = screen.getByText(/no items in the list/i);
    expect(noItemsMessage).toBeInTheDocument();
  });

  test('when Edit button is clicked, then the input is filled with the item value for editing', () => {
    const editButton = screen.getAllByLabelText('edit')[0]; // Get the edit button of the first item
    fireEvent.click(editButton);

    const input = screen.getByPlaceholderText('✍️ Add or Edit Items...');
    expect(input.value).toBe('apple'); // Input should be filled with 'apple'
  });

  test('when Edit is completed, then the item in the list is updated', () => {
    const editButton = screen.getAllByLabelText('edit')[0]; // Get the edit button of the first item
    fireEvent.click(editButton);

    const input = screen.getByPlaceholderText('✍️ Add or Edit Items...');
    fireEvent.change(input, { target: { value: 'Grapes' } });

    const saveButton = screen.getByRole('button', { name: /edit/i });
    fireEvent.click(saveButton);

    const updatedItem = screen.getByText('Grapes');
    expect(updatedItem).toBeInTheDocument();
    expect(screen.queryByText('apple')).not.toBeInTheDocument(); // 'apple' should be replaced
  });

  test('when no items are in the list, then the "No items in the list" message appears', () => {
    const deleteAllButton = screen.getByText(/delete all/i);
    fireEvent.click(deleteAllButton);

    const noItemsMessage = screen.getByText(/no items in the list/i);
    expect(noItemsMessage).toBeInTheDocument();
  });
});

