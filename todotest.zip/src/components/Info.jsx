import { Container, List, ListItem, Typography } from "@mui/material";
import React, { Component } from "react";

class Info extends Component {
  render() {
    return (
      <Container>
        <List>
          <ListItem>
            <Typography variant="h6">
              Documentation :
            </Typography>
          </ListItem>
          <ListItem>
          Firstly I created a react project using vite
          </ListItem>
          <ListItem>
          Testing React component using jest and Enzyme .
          Shallow Testing and Unit Testing 
          </ListItem>
        </List>
      </Container>
    );
  }
}
export default Info;
